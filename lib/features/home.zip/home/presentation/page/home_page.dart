import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:get/get.dart';

import '../../../../core/utils/constants.dart';
import '../../../../global/presentation/components/custom_texfield.dart';
import '../../../../global/presentation/components/custom_text_widget.dart';
import '../../controller/home_controller.dart';
import '../components/custom_end_dower_widgets.dart';


class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeController>(builder: (controller) {
      GlobalKey<FormState> formKey = GlobalKey<FormState>();
      controller.scrollController.addListener(() {
        if (controller.scrollController.position.userScrollDirection ==
            ScrollDirection.reverse) {
          controller.showAppbar = false;
          controller.update();
        }
        if (controller.scrollController.position.userScrollDirection ==
            ScrollDirection.forward) {
          controller.showAppbar = true;
          controller.update();
        }
      });
      return Scaffold(
        key: _scaffoldKey,
        drawer: const CustomEndDower(),
        body: CustomScrollView(
          controller: controller.scrollController,
          shrinkWrap: true,
          scrollDirection: Axis.vertical,
          slivers: [
            SliverAppBar(
              expandedHeight: 140,
              titleSpacing: 0,
              floating: true,
              pinned: true,
              snap: true,
              backgroundColor: primaryColor,
              leading: IconButton(
                  onPressed: () {
                    _scaffoldKey.currentState!.openDrawer();
                  },
                  icon: const Icon(
                    Icons.menu,
                    color: Colors.white,
                  )),
              title: controller.showAppbar
                  ? Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        // CustomText(text: "Current Location",fontWeight: FontWeight.w400,fontSize: 12,color: Colors.grey,),
                        // Padding(padding:  EdgeInsets.only(left: 8),
                        // child: Row(
                        //   children: [
                        //      const Icon(Icons.location_on_outlined,color: Colors.blue,),
                        //     CustomText(text: "Please Select",fontWeight: FontWeight.w900,fontSize: 14,),
                        //       const Icon(Icons.arrow_drop_down,color: Colors.blue,size: 28,),
                        //   ],
                        // ),
                        // ),
                        const SizedBox(
                          height: 5.0,
                        ),
                        CustomText(
                          text: "Find Your Dream Home Today!",
                          fontWeight: FontWeight.w700,
                          fontSize: 22,
                          color: Colors.white,
                        ),
                        //  CustomText(text: "Your One-Stop Destination For\n Renting & Buying Properties",fontWeight: FontWeight.bold,fontSize: 12,color: Colors.white,maxLines: 2,),
                      ],
                    )
                  : null,
              flexibleSpace: FlexibleSpaceBar(
                titlePadding: EdgeInsets.only(
                    left: controller.showAppbar ? 16.0 : 60,
                    right: 16.0,
                    bottom: 12),
                title: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start, // Align to the left
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [

                    CustomTextField(
                      hint: "Search",
                      //formKey: formKey,
                      controller: controller.searchController,
                      errorMessage: "errorMessage",
                      onTextChanged: (value) {
                        if (value.isNotEmpty) {
                          controller.isSearching.value = true;
                          print(
                              "Searching Item :$value ${controller.isSearching.value} ");
                        } else if (value.isEmpty) {
                          controller.isSearching.value = false;
                          print(
                              "Searching Item :$value ${controller.isSearching.value} ");
                        }
                        print(
                            "Searching Item :$value ${controller.isSearching.value} ");
                      },
                      borderRadius: 12.0,
                      enableLabel: false,
                      enableUnderline: false, hintTextSize: 17,
                      enableBorder: true,
                      prefixIcon: const Icon(
                        Icons.search,
                        color: Colors.grey,
                        size: 28,
                      ),
                      suffixIcon: InkWell(
                        onTap: () {

                        },
                        focusColor: Colors.black54,
                        child: const Icon(
                          Icons.tune,
                          color: Colors.grey,
                          size: 28,
                        ),
                      ),
                      filled: true,
                      fillColor: Colors.grey.shade200,
                      borderColor: Colors.grey.shade200,
                      paddingBetweenIconAndContent: 3.0,
                      isRequired: false,
                    )
                  ],
                ),
                background: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.asset(
                      'assets/images/background.png',
                      fit: BoxFit.cover,
                    ),
                    Container(
                      color: Colors.black.withOpacity(0.4), // Adjusts opacity
                    ),
                  ],
                ),
              ),
            ),

          ],
        ),
      );
    });
  }
}
