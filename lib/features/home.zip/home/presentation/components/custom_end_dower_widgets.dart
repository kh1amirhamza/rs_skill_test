import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../core/routes/routes.dart';
import '../../../../core/utils/constants.dart';
import '../../../../global/presentation/components/custom_image_view.dart';

class CustomEndDower extends StatelessWidget {
  const CustomEndDower({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: primaryColor,
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          SizedBox(
            height: 100,
            child: Stack(
              fit: StackFit.expand,
              children: [
                const DrawerHeader(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    // image: const DecorationImage(
                    //   image: AssetImage('assets/images/background.png'),
                    //   fit: BoxFit.cover,
                    // ),
                  ),
                  child: CustomImageView(
                    imageType: CustomImageType.assets,
                    imageData: "assets/images/logo.png",
                    height: 100,
                    boxFit: BoxFit.fitHeight,
                  ),
                ),
                Positioned(
                    top: 5,
                    right: 5,
                    child: IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: const Icon(
                        Icons.close,
                        color: primaryColor,
                      ),
                      color: Colors.black12,
                    ))
              ],
            ),
          ),
          ListTile(
            leading: const Icon(
              Icons.dashboard,
            ),
            title: const Text('Dashboard'),
            onTap: () {
              // Handle the tap
            },
          ),
          ListTile(
            leading: const Icon(Icons.cabin),
            title: const Text('My Properties'),
            onTap: () {
              // Handle the tap
            },
          ),
          ListTile(
            leading: const Icon(Icons.home_work_outlined),
            title: const Text('Add Properties'),
            onTap: () {
              // Handle the tap
              Navigator.pop(context);
              Get.toNamed(Routes.addProperties);
            },
          ),
          ListTile(
            leading: Icon(Icons.account_circle),
            title: Text('Profile'),
            onTap: () {
              // Handle the tap
            },
          ),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text('Settings'),
            onTap: () {
              // Handle the tap
            },
          ),
          ListTile(
            leading: Icon(Icons.contact_mail),
            title: Text('Contact Us'),
            onTap: () {
              // Handle the tap
            },
          ),
          ListTile(
            leading: Icon(Icons.description_outlined),
            title: Text('About Us'),
            onTap: () {
              // Handle the tap
            },
          ),
          ListTile(
            leading: Icon(Icons.login_outlined),
            title: Text('Login'),
            onTap: () {
              // Handle the tap
            },
          ),
        ],
      ),
    );
  }
}
