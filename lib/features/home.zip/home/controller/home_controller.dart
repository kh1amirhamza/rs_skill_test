

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:get/get_rx/get_rx.dart';

class HomeController extends GetxController{

  TextEditingController searchController = TextEditingController();
   FocusNode searchFocusNode = FocusNode();
  ScrollController scrollController = ScrollController();
  bool showAppbar = true;
  RxBool isSearching = false.obs;


@override
  void dispose() {
    // TODO: implement dispose
  scrollController.dispose();
  searchFocusNode.dispose();
    super.dispose();
  }
}