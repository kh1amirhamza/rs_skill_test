import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rs_skill_test/features/customer/controllers/customer_controller.dart';

class CustomerPage extends StatefulWidget {
  const CustomerPage({super.key});

  @override
  State<CustomerPage> createState() => _CustomerPageState();
}

class _CustomerPageState extends State<CustomerPage> {
  CustomerController customerController = Get.find<CustomerController>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Customer"),),
      body: GetBuilder(
        init: customerController,
        builder: (controller){
          return Container();
        },
      ),
    );
  }
}
