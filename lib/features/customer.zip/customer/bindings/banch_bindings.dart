import 'package:get/get.dart';
import 'package:rs_skill_test/features/customer/controllers/customer_controller.dart';

class CustomerBindings extends Bindings{
  @override
  void dependencies() {
    // TODO: implement dependencies
    Get.lazyPut(() => CustomerController());
  }

}