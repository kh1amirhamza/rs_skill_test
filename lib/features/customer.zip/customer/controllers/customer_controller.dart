import 'package:get/get.dart';

class CustomerController extends GetxController{

}