import 'package:get/get.dart';

import '../controllers/supplier_controller.dart';

class CustomerBindings extends Bindings{
  @override
  void dependencies() {
    // TODO: implement dependencies
    Get.lazyPut(() => SupplierController());
  }

}