import 'package:get/get.dart';

class SupplierController extends GetxController{

}