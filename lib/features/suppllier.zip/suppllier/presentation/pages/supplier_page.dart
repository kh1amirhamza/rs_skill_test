import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rs_skill_test/features/suppllier/controllers/supplier_controller.dart';

class SupplierPage extends StatefulWidget {
  const SupplierPage({super.key});

  @override
  State<SupplierPage> createState() => _SupplierPageState();
}

class _SupplierPageState extends State<SupplierPage> {
  SupplierController supplierController = Get.find<SupplierController>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Supplier"),),
      body: GetBuilder(
        init: supplierController,
        builder: (controller){
          return Container();
        },
      ),
    );
  }
}
