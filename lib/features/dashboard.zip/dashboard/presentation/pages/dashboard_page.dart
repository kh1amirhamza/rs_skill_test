import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../main_page/controllers/main_page_controller.dart';
import '../../../transaction/presentation/widgets/invoice_card.dart';
import '../../../transaction/presentation/widgets/transaction_item.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        leading: IconButton(
            onPressed: () {
              Get.find<MainPageController>()
                  .scaffoldKey
                  .currentState!
                  .openDrawer();
            },
            icon: const Icon(
              Icons.menu,
              color: Colors.black,
            )),
        title: const Text("Dashboard"),
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: const EdgeInsets.only(bottom: 70),
          padding: const EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Center(
              //   child: CustomImageView(
              //     height: 140,
              //     width: 140,
              //     isOval: true,
              //     borderWidth: 4,
              //     boxFit: BoxFit.cover,
              //     imageType: CustomImageType.assets,
              //     imageData: "assets/images/default_image.jpeg",
              //   ),
              // ),
              const Text(
                "Transaction List",
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey),
              ),
              const SizedBox(
                height: 10,
              ),
              GridView.builder(
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: 3,
                itemBuilder: (context, index) {
                  return TransactionItem(
                      onItemClick: () {},
                      onReceiptClick: () {
                        Get.to(() => InvoiceCard());
                      },
                      transactionID: "UYEUJFJHFJHJ",
                      paymentMethod: "Paypal",
                      amount: 5.0,
                      status: "Paid");
                },
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: (Get.width > 600
                      ? 2
                      : 1), // 2 columns for tablet, 1 for mobile
                  mainAxisSpacing: 8.0,
                  crossAxisSpacing: 8.0,
                  childAspectRatio: 3.5, // Adjust the aspect ratio as needed
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
